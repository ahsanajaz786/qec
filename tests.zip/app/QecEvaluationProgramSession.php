<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QecEvaluationProgramSession extends Model
{
    protected $fillable=['qec_evaluation_id','program_session_id'];
}
