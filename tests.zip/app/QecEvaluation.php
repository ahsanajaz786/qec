<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QecEvaluation extends Model
{
    protected $fillable=['title','startDate','endDate','status'];
}
